#include <iostream>

using namespace std;
    int sumNums(int number, int sum) {
        for (int i = 0; i <= number; i++){
            sum += i;
        }
        return sum;
}

int main()
{
    int number, sum;
    
    cout<< "Input the last number of the range starting from 1 : ";
    cin >> number;
    cout << sumNums (number, sum);
    
     
    return 0;
}