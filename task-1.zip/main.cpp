#include <iostream>

using namespace std;
    void natural(int n) {
        for (int i = 1; i < 51; i++){
            cout << i <<" ";
        }
}
int main()
{
    int n;
    
    cout<< "Natural numbers are: ";
    natural(n);
    return 0;
}