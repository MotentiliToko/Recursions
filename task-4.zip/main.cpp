#include <iostream>

using namespace std;
double arrElements( int size) {
        cout << "Array Elements: ";
        for (int i = 0; i < size; i++){
            cout << (i+1) * 2 << " ";
        }
        return 0;
}

int main()
{
    int size;
    cout <<"Input the elements: ";
    cin>> size;
    arrElements(size);
    return 0;
}