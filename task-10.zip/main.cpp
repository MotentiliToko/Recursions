#include <iostream>

using namespace std;
    int factorial(int n) {
        cout << n << endl;
        if(n > 1) {
            return n*factorial(n-1);
        } else {
            return 1;
        }
    }
int main()
{
    int result = factorial(5);
    cout << result << endl;

    return 0;
}